import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        System.out.println("1");
        Scanner scanner = new Scanner(System.in);
        double input = scanner.nextDouble();
        double wynik = (input * 1.8) + 32;
        System.out.println(wynik);

    }
}